﻿using System;
using System.Collections.Generic;

namespace Antiplagiarism
{
    public static class LongestCommonSubsequenceCalculator
    {
        public static List<string> Calculate(List<string> first, List<string> second)
        {
            var optimal = CreateOptimizationTable(first, second);
            return RestoreAnswer(optimal, first, second);
        }

        ///
        private static int[,] CreateOptimizationTable(List<string> first, List<string> second)
        {
            int[,] optimal = new int[first.Count + 1, second.Count + 1];
            for (int i = 0; i <= first.Count; ++i) optimal[i, 0] = i;
            for (int i = 0; i <= second.Count; ++i) optimal[0, i] = i;

            ///OPT(i, j) = OPT(i - 1; j - 1) + 1
            ///OPT(i, j) = MAX(OPT(i - 1; j), OPT(i, j - 1))
            for (int i = 1; i <= first.Count; ++i)
                for (int j = 1; j <= second.Count; ++j)
                {
                    optimal[i, j] = optimal[i - 1, j - 1] + 1;
                    if (first[i - 1] != second[j - 1])
                        optimal[i, j] = Math.Max(optimal[i - 1, j], optimal[i, j]);
                }
            return optimal;
                //for (int i = 0; i <= first.Count; ++i) optimal[i, 0] = i;
                //for (int i = 0; i <= second.Count; ++i) optimal[0, i] = i;
                //for (int i = 1; i <= first.Count; ++i)
                //    for (int j = 1; j <= second.Count; ++j)
                //    {
                //        double d = TokenDistanceCalculator.GetTokenDistance(first[i - 1], second[j - 1]);
                //        optimal[i, j] = optimal[i - 1, j - 1];
                //        if (first[i - 1] != second[j - 1])
                //        {
                //            optimal[i, j] = MinimalOfThree(optimal[i - 1, j] + 1, optimal[i, j - 1] + 1, optimal[i - 1, j - 1] + d);
                //        }
                //    }

            //var opt = new int[first.Count + 1, second.Count + 1];
            //for (int i = first.Count - 1; i >= 0; i--)
            //    for (int j = second.Count - 1; j >= 0; j--)
            //        var d = TokenDistanceCalculator.GetTokenDistance(first[i], second[j]);
            //        if (TokenDistanceCalculator.GetTokenDistance(first[i], second[j]) == 0)
            //            opt[i, j] = 1 + opt[i + 1, j + 1];
            //        else
            //            opt[i, j] = Math.Max(opt[i + 1, j], opt[i, j + 1]);
            //return opt;
        }

        private static List<string> RestoreAnswer(int[,] optimal, List<string> first, List<string> second)
        {

            var res = new List<string>();
            for (int i = 0, j = 0; optimal[i, j] != 0 && i < first.Count && j < second.Count;)
                if (TokenDistanceCalculator.GetTokenDistance(first[i], second[j]) == 0)
                {
                    res.Add(first[i]);
                    i++;
                    j++;
                }
                else
                    if (optimal[i, j] == optimal[i + 1, j])
                    i++;
                else
                    j++;
            return res;

            //int x = first.Count;
            //int y = second.Count;


            //if (first.Count == 0 && second.Count == 0)
            //    return new List<string>();
            //if (first[first.Count - 1] == second[second.Count - 1])
            //{
            //    var result = RestoreAnswer(optimal, first, second);
            //    result.Add(first[first.Count - 1]);
            //    return result;
            //}
            //if (optimal[first.Count, second.Count - 1] > optimal[first.Count - 1, second.Count])
            //    return RestoreAnswer(optimal, first, second);
            //return RestoreAnswer(optimal, first, second);
        }
    }
}